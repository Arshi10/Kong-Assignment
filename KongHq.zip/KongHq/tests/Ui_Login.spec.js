import { test, expect } from '@playwright/test';
const locators = require('../node_modules/Locator');
const config = require('../node_modules/config');
const LoginPage = require("../WorkFlows/LoginPage");
let page1 ;

test('Test for login through UI', async({page}) =>
 {
    const loginPage_obj = new LoginPage(page);
    await loginPage_obj.navigate();

});
 

