const {test, expect, request} = require('@playwright/test');
const config = require('../node_modules/config');
const ApiUtils = require('../WorkFlows/ApiUtils');

const Token = config.configuration.Token ;
let ID;
let Api_Product_Name;
let Description = "Some_Random_String";
let Product_Version_ID;
let apiUtil_obj;

//It's like a setup function, it will run before all the tests
test.beforeAll('creating require objects', async() => {
    //Creating Api Utils Object to access its methods
    apiUtil_obj = new ApiUtils();
    
});


test('Test 1 - Creating New Api Product', async() => {
    const apiContext = await request.newContext();
    //Generating Random Name so that it won't clash the product
    //creation
    const timestamp = Date.now(); 
    const name = "Automation";
    Api_Product_Name = `${name}_${timestamp}`;
    const body = {
        "name": `${Api_Product_Name}`,
        description: `${Description}`
    };
    const postResponse = await apiContext.post( config.configuration.apiBaseUrl + "api-products",
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            },
            data:body
        });
    //Making sure response code is 201
    expect(postResponse.status()).toBe(201);

    //Fetching the ID of the Api Product
    const data1 = await postResponse.text();
    ID = await apiUtil_obj.findDataInJson(data1, "id");

});

test('Test 2: Get ApiProduct created in Test 1 ', async() => {
    const apiContext = await request.newContext();
    
    const getResponse = await apiContext.get(config.configuration.apiBaseUrl + "api-products/" + `${ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            }
           
        });
    //Making sure response is 200 
    expect(getResponse.ok()).toBeTruthy();

    //Confirming the product version count is 0
    const data1 = await getResponse.text();
    let version_count = await apiUtil_obj.findDataInJson(data1, "version_count");
    expect(version_count).toBe(0);
    
});


test('Test 3: Attach Product Version to Api Product of Test-1', async() => {
    const apiContext = await request.newContext();
    const body = {
        "name": "Test-Product-versions"
    };
    const postResponse = await apiContext.post(config.configuration.apiBaseUrl + "api-products/" + `${ID}` + "/product-versions",
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            },
            data:body
         
        });
    //Making sure APi response is 201
    expect(postResponse.status()).toBe(201);

    //Fetching and storing the Product Version Id
    const data1 = await postResponse.text();
    Product_Version_ID = await apiUtil_obj.findDataInJson(data1, "id");
    
});


test('Test 4: Making Sure Version attched in Test-3 is Reflecting', async() => {
    const apiContext = await request.newContext();
    
    const getResponse = await apiContext.get(config.configuration.apiBaseUrl + "api-products/" + `${ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            }
           
        });

    //Making sure APi response is 200
    expect(getResponse.ok()).toBeTruthy();

    //Fetching the product version_count and making sure it has become 1
    const data1 = await getResponse.text();
    let version_count = await apiUtil_obj.findDataInJson(data1, "version_count");
    expect(version_count).toBe(1);
    

});

test('Test 5: Updating description of Api Product created in Test-1', async() => {
    const apiContext = await request.newContext();
    Description = `${Description}` + "_updated";
    const body = {
        "name": `${Api_Product_Name}`,
        description: `${Description}`
    };
    const patchResponse = await apiContext.patch(config.configuration.apiBaseUrl + "api-products"+ `${ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            },
            data:body
        });
    //Making sure API response is 200
    expect(patchResponse.ok()).toBeTruthy();

    //Fetching the Api Product description and comparing
    //whether the newly added description is visible or not
    const data1 = await patchResponse.text();
    let description_value = await apiUtil_obj.findDataInJson(data1, "description");
    expect(description_value).toBe(Description);

});


test('Test 6: Updating Product Version of Api Product created in Test-1', async() => {
    const apiContext = await request.newContext();
    const body = {
        "name": "product_version_name_changed",
        "gateway_service": null
    };
    const patchResponse = await apiContext.patch(config.configuration.apiBaseUrl + "api-products/" + `${ID}` + "/product-versions/" + `${Product_Version_ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            },
            data:body
        });
    //Making sure Api response is 200
    expect(patchResponse.ok()).toBeTruthy();

    //From Api response, parsing the product version name and 
    //making sure new name is getting reflected
    const data1 = await patchResponse.text();
    let updated_version_name = await apiUtil_obj.findDataInJson(data1, "name");;
    expect(updated_version_name).toBe("product_version_name_changed");

});

//Additional Test to make sure after changing product description 
//and version, product is still intact 
test('Test 7: After updating description and Product version, making sure product is still intact', async() => {
    const apiContext = await request.newContext();
    const getResponse = await apiContext.get(config.configuration.apiBaseUrl + "api-products/" + `${ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            }
           
        });

    //Making sure Api response is 200
    expect(getResponse.ok()).toBeTruthy();

    //Making sure correct discrion is showing for the Api Product
    const data1 = await getResponse.text();
    let description_value = await apiUtil_obj.findDataInJson(data1, "description");
    expect(description_value).toBe(Description);
    

});

test('Test 8: Cleanup - Deleting the Api product', async() => {
    const apiContext = await request.newContext();
    const deleteResponse = await apiContext.delete(config.configuration.apiBaseUrl + "api-products/" + `${ID}`,
        {
            headers: {
                'Authorization': `Bearer ${Token}`,
                'Content-Type' : 'application/json'
            }
           
        });

    //Making sure Api response is 204
    expect(deleteResponse.status()).toBe(204);

    });






