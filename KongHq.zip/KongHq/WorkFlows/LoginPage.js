const { expect } = require('@playwright/test');
const locators = require('../node_modules/Locator');
const config = require('../node_modules/config');

let page1 ;

class LoginPage {
    constructor(page) {
        this.page = page;
    }

    async navigate() {
        console.log("config.uiBaseUrl " + config.configuration.uiBaseUrl);
        await this.page.goto(config.configuration.uiBaseUrl);
        const page1Promise = this.page.waitForEvent('popup');
        await this.page.locator('a').filter({ hasText: locators.login.signupText }).click();
        const page1 = await page1Promise;
        await page1.getByRole('link', { name: locators.login.linkLogin }).click();
        //await page1.waitForTimeout(3000);
        await page1.getByLabel(locators.login.usernameField).click();
        await page1.getByLabel(locators.login.usernameField).fill(config.configuration.username);
        await page1.getByLabel(locators.login.passwordField).click();
        await page1.getByLabel(locators.login.passwordField).fill(config.configuration.password);
        await page1.waitForTimeout(3000);
        await page1.getByRole('button', { name: locators.login.submitButton, exact: true }).click();
        await page1.waitForEvent('load');

        //For one minute, every sec keep polling and checking
        //the KongHq home page title
        const maxWaitTime = 60000;
        const pollingInterval = 1000;
        const startTime = Date.now();
        let titleMatches = false
        while (Date.now() - startTime < maxWaitTime ){
            const title = await page1.title();
            console.log("title is " + title);
            if (title == "Home | Konnect"){
                console.log("login sucess!");
                titleMatches = true;
                break;
                } else{
                    console.log("login failure");
                    await page1.waitForTimeout(pollingInterval);
                }
        }
        expect(titleMatches).toBe(true);

        return page1
    }

}

module.exports = LoginPage;
