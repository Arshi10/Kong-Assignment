const {Module} = require("module")
class ApiUtils{
    constructor(){      
    }

    async findDataInJson(data, key){
        const jsonObj = JSON.parse(data);
        let ret = jsonObj[key];
        return ret

    }

}

module.exports = ApiUtils;